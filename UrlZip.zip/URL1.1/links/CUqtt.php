<?php 
$UrlBzh = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];
 session_start();
$_SESSION["UrlBzh"]= $UrlBzh;
 header("Location:http://localhost:8888/WEBDEV/URL/index.php?action=Reduction");
?>
