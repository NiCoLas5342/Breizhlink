<?php 
$UrlBzh = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];
 session_start();
$_SESSION["UrlBzh"]= $UrlBzh;
 header("Location:https://breizhlink.000webhostapp.com/URL1.1/index.php?action=Reduction");
?>
