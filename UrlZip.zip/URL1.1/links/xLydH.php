<?php 
 
header("Location: https://www.bouyguestelecom.fr/mon-compte/dashboard#");
?> 
