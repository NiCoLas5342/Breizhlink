<?php 
 session_start ();
$UrlBzh = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];
$_SESSION["UrlBzh"]= $UrlBzh;
header("Location:https://breizhlink.000webhostapp.com/URL1.1/index.php?action=Reduction");
?>
