<?php 
 Require_once '../Modele/Requete.php'; 
include '../Vue/links.php' ; ?>
<form action='' method='post'>
<p id="MdpLien">Ce lien est protégé par un mot de passe !<br>Entrez le mot de passe pour acceder au lien Breizhlink<br>
<input type="password" name="password" /><input type="submit" value="Valider" />
<br><img src="../Vue/logo.png"></p>
</form>
<?php 
if(!empty($_POST["password"])){
$url = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];
$https = "https://";
$mdp = $_POST["password"];
if($_POST["password"] != null){ 
$donnee = Requete::addMdpHash($https.$url);
foreach($donnee as $uneLigne){$mdpHash = $uneLigne["mdp"];}
if (password_verify($mdp, $mdpHash)){ 
echo "<script type='text/javascript'>document.location.replace(' https://www.instagram.com/?hl=fr');</script>"; }
else {echo "<br>Mot de passe incorrect";
} 
 } 
 } 

?> 
