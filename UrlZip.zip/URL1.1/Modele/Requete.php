<?php
require_once 'Connexion.php';
class Requete extends Connexion {

    public static function ajouter($email,$nom,$password)// Requete pour inserer une nouvelle donnée
    {
        try {
            
            $sql = "INSERT INTO Profils(mail,nom,password) VALUES ('$email','$nom','$password') ";
            Connexion::$pdo->query($sql);
        }
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }


    public static function addUrl($url,$mdp,$urlBzh)// Requete pour inserer une nouvelle donnée
    {
        try {
            
            $sql = "INSERT INTO Url_NoProfils(Url,mdp,UrlBzh) VALUES ('$url','$mdp','$urlBzh') ";
            Connexion::$pdo->query($sql);

        }
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
      }

    public static function addUrlMdp($idProfils,$url,$mdp,$UrlBzh,$dateCreation)// Requete pour inserer une nouvelle donnée
    {
        try {
            
            $sql = "INSERT INTO Url_Profils(id_users,Url,mdp,UrlBzh,dateCreation) VALUES ('$idProfils','$url','$mdp','$UrlBzh','$dateCreation') ";
            //echo "<br>".$sql ;
            Connexion::$pdo->query($sql);
            
        }
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
       
      }
      
         public static function addUrlDateFin($idProfils,$url,$UrlBzh,$dateFin,$dateCreation)// Requete pour inserer une nouvelle donnée
    {
        try {
            
            $sql = "INSERT INTO Url_Profils(id_users,Url,UrlBzh,DateFin,dateCreation) VALUES ('$idProfils','$url','$UrlBzh','$dateFin','$dateCreation') ";
            Connexion::$pdo->query($sql);
            

        }
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
      }

              public static function addUrlDateDebutFin($idProfils,$url,$UrlBzh,$dateDebut,$dateFin,$dateCreation)// Requete pour inserer une nouvelle donnée
    {
        try {
            
            $sql = "INSERT INTO Url_Profils(id_users,Url,UrlBzh,DateDebut,DateFin,dateCreation) VALUES ('$idProfils','$url','$UrlBzh','$dateDebut','$dateFin','$dateCreation') ";
            //echo "<br>".$sql ;
            Connexion::$pdo->query($sql);
            

        }
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
      }

      public static function addUrlNbrClicsMax($idProfils,$url,$UrlBzh,$NombresClicsMax,$dateCreation)// Requete pour inserer une nouvelle donnée
    {
        try {
            
            $sql = "INSERT INTO Url_Profils(id_users,Url,UrlBzh,NombresClicsMax,dateCreation) VALUES ('$idProfils','$url','$UrlBzh','$NombresClicsMax','$dateCreation') ";
            //echo "<br>".$sql ;
            Connexion::$pdo->query($sql);
            

        }
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
      }
       public static function addUrlDateFinMdp($idProfils,$url,$pass_hash,$UrlBzh,$dateFin,$dateCreation)// Requete pour inserer une nouvelle donnée
    {
        try {
            
            $sql = "INSERT INTO Url_Profils(id_users,Url,mdp,UrlBzh,DateFin,dateCreation) VALUES ('$idProfils','$url','$pass_hash','$UrlBzh','$dateFin','$dateCreation') ";
            Connexion::$pdo->query($sql);
            

        }
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
      }

                    public static function addUrlDateDebutFinMdp($idProfils,$url,$pass_hash,$UrlBzh,$dateDebut,$dateFin,$dateCreation)// Requete pour inserer une nouvelle donnée
    {
        try {
            
            $sql = "INSERT INTO Url_Profils(id_users,Url,mdp,UrlBzh,DateDebut,DateFin,dateCreation) VALUES ('$idProfils','$url','$pass_hash','$UrlBzh','$dateDebut','$dateFin','$dateCreation') ";
            Connexion::$pdo->query($sql);
            

        }
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
      }

            public static function addUrlNbrClicsMaxMdp($idProfils,$url,$pass_hash,$UrlBzh,$NombresClicsMax,$dateCreation)// Requete pour inserer une nouvelle donnée
    {
        try {
            
            $sql = "INSERT INTO Url_Profils(id_users,Url,mdp,UrlBzh,NombresClicsMax,dateCreation) VALUES ('$idProfils','$url','$pass_hash','$UrlBzh','$NombresClicsMax','$dateCreation') ";
            //echo "<br>".$sql ;
            Connexion::$pdo->query($sql);
            

        }
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
      }


       public static function addMdpHash($url)// Requete pour inserer une nouvelle donnée
    {
        try {
            
            $sql = "SELECT mdp FROM Url_NoProfils WHERE UrlBzh = '".$url."'";
            $result = Connexion::$pdo->query($sql);
            return $result->fetchAll();
            
        }
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
      }

    public static function addMdpHashProfils($url)// Requete pour inserer une nouvelle donnée
    {
        try {
            
            $sql = "SELECT mdp FROM Url_Profils WHERE UrlBzh = '".$url."'";
            $result = Connexion::$pdo->query($sql);
            return $result->fetchAll();
            
        }
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
      }

      public function addClics($NombresClicsMaj,$UrlBzh){
        try {
            
            $sql = "UPDATE Url_Profils SET NombresClics = '$NombresClicsMaj' WHERE  UrlBzh = '$UrlBzh'";
            $result = Connexion::$pdo->query($sql);
            
            
        }
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
      }
      
 

     public static function RecupUrlProfils($UrlBzh){
        try {
            $sql    = "SELECT * FROM Url_Profils WHERE UrlBzh = '".$UrlBzh."'";
            $result = Connexion::$pdo->query($sql);
            return $result->fetchAll();
        }
        catch (PDOException $ex) {
            echo $ex->getMessage();
            die('Problème lors de la connexion à la base de donnée');
        }
     }


      public static function RecupidUser($login){
        try {
            $sql    = "SELECT id FROM Profils WHERE nom = '".$login."'";
            $result = Connexion::$pdo->query($sql);
            return $result->fetchAll();
        }
        catch (PDOException $ex) {
            echo $ex->getMessage();
            die('Problème lors de la connexion à la base de donnée');
        }
     }

        public static function RecapUrl($id_users){
                try {
                    $sql    = "SELECT * FROM Url_Profils WHERE id_users = '".$id_users."'";
                    $result = Connexion::$pdo->query($sql);
                    return $result->fetchAll();
                }
                catch (PDOException $ex) {
                    echo $ex->getMessage();
                    die('Problème lors de la connexion à la base de donnée');
                }
             }

     public static function AllsMails() // Requete pour afficher toutes les données de la latble DN (données nutritionnelles)
    {
        try {
            $sql    = "SELECT mail FROM Profils";
            $result = Connexion::$pdo->query($sql);
            return $result->fetchAll();
        }
        catch (PDOException $ex) {
            echo $ex->getMessage();
            die('Problème lors de la connexion à la base de donnée');
        }
    }

     public static function RecupMdp($nom) 
    {
        try {
            $sql = "SELECT password FROM Profils WHERE nom ='".$nom."' ";
            $result = Connexion::$pdo->query($sql);
             return $result->fetchAll();
        }
        catch (PDOException $ex) {
            echo $ex->getMessage();
            die('Problème lors de la connexion à la base de donnée');
        }
    }

     public static function AfficherTableaux() // Requete pour afficher toutes les données de la latble DN (données nutritionnelles)
    {
        try {
            $sql    = "SELECT * FROM Profils";
            $result = Connexion::$pdo->query($sql);
            return $result->fetchAll();
        }
        catch (PDOException $ex) {
            echo $ex->getMessage();
            die('Problème lors de la connexion à la base de donnée');
        }
    }
      

         public static function AfficherUneLigne($id)
    {
        try {
            $sql    = "SELECT * FROM Profils WHERE id = '".$id."'";
            $result = Connexion::$pdo->query($sql);
            return $result->fetchAll();
        }
        catch (PDOException $ex) {
            echo $ex->getMessage();
            die('Problème lors de la connexion à la base de donnée');
        }
    }

     public static function delete($id)// Requete pour inserer une nouvelle donnée
    {
        try {
            
            $sql = "DELETE FROM Profils WHERE id ='".$id."'";
            Connexion::$pdo->query($sql);
        }
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }


     public static function update($id,$email,$nom)// Requete pour modifier une donnée excitante
    {
        try {
            $sql = "UPDATE Profils SET mail='$email',nom='$nom' WHERE id='$id' ";
            Connexion::$pdo->query($sql);
        }
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }
 

          public static function SearchUneLigne($recherche)
    {
        try {
            $sql = "SELECT * from Profils where id = '".$recherche."' or mail = '".$recherche."' or nom = '".$recherche."' ";
            $result = Connexion::$pdo->query($sql);
            return $result->fetchAll();
        }
        catch (PDOException $ex) {
            echo $ex->getMessage();
            die('Problème lors de la connexion à la base de donnée');
        }
    }


    public static function GenereIdProfils($login){
        try{
            $sql = "SELECT id FROM Profils WHERE nom = '".$login."'";
            $result = Connexion::$pdo->query($sql);
            return $result->fetchAll();
        }
         catch (PDOException $ex) {
            echo $ex->getMessage();
            die('Problème lors de la connexion à la base de donnée');
        }

    }


        public static function GenereUrlCreationMois($mois){
        try{
            $sql = "SELECT count(id) as nombre from Url_Profils where dateCreation between '2019-".$mois."-01' and '2019-".$mois."-30'";
            $result = Connexion::$pdo->query($sql);
            return $result->fetchAll();
        }
         catch (PDOException $ex) {
            echo $ex->getMessage();
            die('Problème lors de la connexion à la base de donnée');
        }

    }


   
}

?>


