<!DOCTYPE html>
<html>
    <head>
    <!--	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0/css/bootstrap.min.css">-->
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <?php include 'links.php' ;  ?>
        <title>URL</title>
    </head>

    <body>

 <!--<div class="initial-load-animation">
  <div class="linkedin-image"></div>
  <div class="loading-bar">
    <div class="blue-bar"></div>
  </div>
</div>-->



<div>
    	    <header>
        <?php include 'Header.php' ; ?> 
      </header>

    <form action="index.php?action=racourcir" method="post">

<div class="row" id="titre">
  <label for="example-url-input" class="col-lg-12">INDIQUER VOTRE URL À RACCOURCIR </label>
</div>

<div class="row">
  <div class="col-lg-2"></div>
  <div class="col-lg-8">
    <input class="form-control" type="url" name="url" placeholder="https://getbootstrap.com" id="example-url-input">
  </div>
</div>

<div class="row" id="secure">
 <div class="col-lg-2"></div>
 <div class="col-lg-3">
  <label class="form-check-label">
    &nbsp;&nbsp;&nbsp;&nbsp;
    <input class="form-check-input" type="checkbox" name="checkbox" id="check" >
    Sécurisée avec mot de passe
  </label>
</div>
<div class="col-lg-2" >
    <label for="inputPassword2" class="sr-only">Password</label>
    <input type="password" class="form-control" id="inputPassword2" name="Password" placeholder="Password">
</div>
</div>

    <div class="form-group row" id="Raccourcie">
      <div class="offset-sm-2 col-sm-10">
        <button type="submit" name="ctl" value="reduction" class="btn btn-primary" id="racourcii">Racourcir</button>
      </div>
    </div>
</form>

<?php if(isset($_POST['ctl']) and isset($_SESSION['i'])){?>
<div class="row">
  <div class="col-lg-2"></div>
  <div class="col-lg-10">

    <p>Votre URL racourcie ->
<a href="https://breizhlink.000webhostapp.com/URL1.1/links/<?php echo $_SESSION['i'] ;?>.php">https://breizhlink.000webhostapp.com/URL1.1/links/<?php echo $_SESSION['i'] ;?>.php</a></p>
  </div>

<?php }?>


    <div class="offset-sm-2 col-sm-10">
      <p>Créer un compte pour voir nos autres options possibles
      </p>
    </div>




</div>
</div>
<?php include 'footer.php' ; ?> 
    </body>

    <!-- <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
<script type="text/javascript">

    $(document).ready(function(){
      $(".initial-load-animation").fadeOut(5000,function(){
        $("#page").fadeIn(1000);
      });
      })
    
  </script>-->



</html>
