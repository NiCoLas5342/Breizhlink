<?php 
include 'links.php' ; 
echo $url; 
echo url racourcie ; 
?>


