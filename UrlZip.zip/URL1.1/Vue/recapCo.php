<?php
//session_start();
Require_once './Modele/Requete.php';

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'links.php' ;  ?>
    <script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/series-label.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
    <title>URL</title>
  </head>
  <body>
    <header>
      <?php include 'HeaderCo.php' ; ?>
    </header>
    <br><br><br><br>
    <div class="row">
    	<div class="col-lg-3"></div>
    	<div class="col-lg-6">
    <p><h5>Recapitulatifs de vos Url Breizhlink crées avec le nombres de clics indiqué</h5></p>
</div>
</div>
<div class="row">
	<div class="col-lg-2"></div>
  <div class="col-lg-8">
		    <table class="table">
		  <thead class="thead-dark">
		    <tr>
		      <th scope="col">Nombres de clics</th>
		      <th scope="col">Url</th>
		      <th scope="col">UrlBzh</th>
		      <th scope="col">Date Creation</th>
		    </tr>
		  </thead>
		  <tbody>
		  <?php 
		 
          $resultat = requete::RecupidUser($_SESSION['login']);
			$IdUser = $resultat[0]['id'];
			$donnee = requete::RecapUrl($IdUser);
              foreach ($donnee as $uneLigne) {
		    	?>
		    <tr>
		      <th scope="row"><?php echo $uneLigne['NombresClics'] ; ?></th>
		      <td><?php echo $uneLigne['Url'] ; ?></td>
		      <td><?php echo $uneLigne['UrlBzh'] ; ?></td>
		      <td><?php echo $uneLigne['dateCreation'] ; ?></td>
		    </tr>
		    <?php 
 					}
		    ?>
		  </tbody>
		</table>
	</div>
</div>


<br><br><br>
<?php 

$Janvier = requete::GenereUrlCreationMois(01);
$Fevrier = requete::GenereUrlCreationMois(02);
$Mars = requete::GenereUrlCreationMois(3);
$Avril = requete::GenereUrlCreationMois(4);
$Mai = requete::GenereUrlCreationMois(05);
$Juin = requete::GenereUrlCreationMois(06);
$Juillet = requete::GenereUrlCreationMois(07);
$Aout = requete::GenereUrlCreationMois(8);
$Septembre = requete::GenereUrlCreationMois(9);
$Octobre = requete::GenereUrlCreationMois(10);
$Novembre = requete::GenereUrlCreationMois(11);
$Decembre = requete::GenereUrlCreationMois(12);

?>

<div id="container"></div>

      <script>

		Highcharts.chart('container', {

		  title: {
		    text: 'Nombres de lien créer par mois'
		  },

		  subtitle: {
		    text: 'Source: Breizhlink.com'
		  },

		  yAxis: {
		    title: {
		      text: 'Nombres de lien'
		    }
		  },
		   xAxis: {
           
           categories: ['Janvier', 'Fevrier', 'Mars','Avril','Mai','Juin','Juillet','Aout','Septembre','Octobre','Novembre','Decembre']
            },

		  legend: {
		    layout: 'vertical',
		    align: 'right',
		    verticalAlign: 'middle'
		  },



		  series: [{
		    name: '',
		    data: [<?php echo $Janvier [0]['nombre'] ;?>,
		     <?php echo $Fevrier[0]['nombre'] ;?>,
		     <?php echo $Mars[0]['nombre'] ;?>,
		      <?php echo $Avril[0]['nombre'] ;?>, 
		      <?php echo $Mai[0]['nombre'] ;?>,
		       <?php echo $Juin[0]['nombre'] ;?>, 
		       <?php echo $Juillet[0]['nombre'] ;?>,
		        <?php echo $Aout[0]['nombre'] ;?>,
		        <?php echo $Septembre[0]['nombre'] ;?>,
		         <?php echo $Octobre[0]['nombre'] ;?>,
		          <?php echo $Novembre[0]['nombre'] ;?>, 
		          <?php echo $Decembre[0]['nombre'] ;?>]
		  }],

		  responsive: {
		    rules: [{
		      condition: {
		        maxWidth: 500
		      },
		      chartOptions: {
		        legend: {
		          layout: 'horizontal',
		          align: 'center',
		          verticalAlign: 'bottom'
		        }
		      }
		    }]
		  }

		});
   </script>





        <?php include 'footer.php' ; ?>
  </body>
</html>