<footer class="page-footer font-small blue">


  <div class="footer-copyright text-center py-3">© 2019 Copyright || Devenir partenaires -  CGV - Mentions légales

   <!-- <a href="https://mdbootstrap.com/education/bootstrap/"> MDBootstrap.com</a>-->
  </div>


</footer>