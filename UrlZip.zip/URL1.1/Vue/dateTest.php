<?php 
echo coucou ;
$today = date("m/d/Y");
$dateValable = date("03/15/2019");
echo "<br>".$today ;

if($dateValable > $today){
	echo blablabla ;
}
else{
	echo "adresse plus valabe" ;
}
?>