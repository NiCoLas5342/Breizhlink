<!DOCTYPE html>
<html>
    <head>
     <?php include 'links.php' ;  ?>
        <meta charset="utf-8" />
        <title>URL</title>
    </head>

    <body>
    	    <header>
        <?php include 'Header.php' ; ?> 
      </header>


<form method="POST" action="index.php?action=racourcir">

<div id="espace"></div>

<div class="row">
  <div class="col-lg-2"></div>
  <div class="col-lg-2">
        <label for="exampleInputEmail1">Email address</label>
 </div>
  <div class="col-lg-5">
        <input type="email" class="form-control" name="email" aria-describedby="emailHelp" placeholder="Enter email" required>
        <small id="emailHelp" class="form-text text-muted"><?php 
        if (isset ($_SESSION['ErreurMail']) ){
        echo $_SESSION['ErreurMail'];
        }
        ?>
         </small> 
   </div>
</div>
 
 <div id="espace"></div>

<div class="row">
  <div class="col-lg-2"></div>
  <div class="col-lg-2">
    <label for="exampleInputEmail1">Pseudo</label>
  </div>
   <div class="col-lg-5">
         <input type="text" class="form-control" name="login" aria-describedby="emailHelp" placeholder="Enter your login" required>
   </div>
</div>

<div id="espace"></div>

<div class="row">
  <div class="col-lg-2"></div>
  <div class="col-lg-2">
    <label for="exampleInputPassword1">Password</label>
  </div>
  <div class="col-lg-5">
    <input type="password" class="form-control" name="password" placeholder="Password" required>
  </div>
</div>

<div id="espace"></div>

<div class="row">
  <div class="col-lg-8"></div>
  <div class="col-lg-2">
    <button type="submit" name="ctl" value="CreationNewCompte" class="btn btn-primary">Creer</button>
  </div>
 </div> 

</form>

   <?php 
   include 'footer.php' ; ?> 
    </body>
 
</html>