<!DOCTYPE html>
<html>
    <head>
    <!--	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0/css/bootstrap.min.css">-->
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <?php include 'links.php' ;  ?>
        <title>URL</title>
    </head>

    <body>
    	    <header>
        <?php include 'Header.php' ; ?> 
      </header>

<form method="POST" action="index.php?action=racourcir">
    </div>
      <div class="form-group">
      <input type="text" class="form-control" name="rechercher"  placeholder="Rechercher" required>
     </div>
  <button type="submit" name="ctl" value="search" class="btn btn-primary">Search</button>
</form>

      <table class="">    
          <thead>
   <tr>
    <th>id</th>
     <th>mail</th>
       <th>nom</th>
            </tr>
          </thead>
          <tbody>
            <tr>
<?php for($i=0;$i<=count($liste)-1;$i++) {  ?>
 <tr>

            <td> <?php  echo $liste[$i]['id'] ; ?> </td>
            <td> <?php   echo $liste[$i]['mail'] ;  ?> </td>
            <td> <?php   echo $liste[$i]['nom'] ; ?> </td> 
                        <td>
              <form method="post" action="index.php?action=creation">
              <button type="submit">ajouter</button>
              </form>
             </td> 
                             <td>  
               <form method="post"  action="index.php?action=racourcir&id=<?php echo $liste[$i]['id'] ; ?>">
              <button type="submit" name="ctl" value="sup">supprimer</button>
              
              </form>
             </td>
                          </td> 
                             <td>  
               <form method="post"  action="index.php?action=racourcir&id=<?php echo $liste[$i]['id'] ; ?>">
              <button type="submit" name="ctl" value="modif">modifier</button>
              
              </form>
             </td>
            </tr>
            <?php } ?>
          </tbody>
        </table>




<?php include 'footer.php' ; ?> 


    </body>
</html>

