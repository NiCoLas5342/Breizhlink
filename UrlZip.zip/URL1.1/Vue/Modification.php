<!DOCTYPE html>
<html>
    <head>
     <?php include 'links.php' ;  ?>
        <meta charset="utf-8" />
        <title>URL</title>
    </head>

    <body>
    	    <header>
        <?php include 'Header.php' ; 
        $ligne = $_SESSION['ligne'] ; 

        ?> 
      </header>


<form method="POST" action="index.php?action=racourcir&id=<?php echo $id ; ?>">
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" name="email" aria-describedby="emailHelp" value="<?php echo $ligne['0']['mail']; ?>" required>
    <small id="emailHelp" class="form-text text-muted"><?php 
   if (isset ($_SESSION['ErreurMail']) ){
    echo $_SESSION['ErreurMail'];
   }
     ?>
     </small>
  </div>
    <div class="form-group">
    <label for="exampleInputEmail1">Pseudo</label>
    <input type="text" class="form-control" name="login" aria-describedby="emailHelp"  value="<?php  echo $ligne['0']['nom'];  ?> " required>
  </div>


  <button type="submit" name="ctl" value="update" class="btn btn-primary">Submit</button>
</form>


   <?php 
   include 'footer.php' ; ?> 
    </body>
 
</html>