<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'links.php' ;  ?>
    <title>URL</title>
  </head>
  <body>
    <header>
      <?php include 'HeaderCo.php' ; ?>
    </header>

    <form action="index.php?action=racourcir" method="post">
<?php 
/*Require_once './Modele/Requete.php'; 
echo $_SESSION['login']; 
echo "<br>".$_SESSION['UrlBzh'];
$resultat = Requete::RecupUrlProfils($_SESSION['UrlBzh']);
$Url = $resultat[0]['Url'] ;
echo"<br>".$Url;
 header("Location:$Url");*/
?>

<div class="row" id="titre">
  <label for="example-url-input" class="col-lg-12">INDIQUER VOTRE URL À RACCOURCIR </label>
</div>

<div class="row">
  <div class="col-lg-2"></div>
  <div class="col-lg-8">
    <input class="form-control" type="url" name="url" placeholder="https://getbootstrap.com" id="example-url-input">
  </div>
</div>

<div class="row" id="secure">
 <div class="col-lg-2"></div>
 <div class="col-lg-3">
  <label class="form-check-label">
    &nbsp;&nbsp;&nbsp;&nbsp;
    <input class="form-check-input" type="checkbox" name="checkbox" id="check" >
    Sécurisée avec mot de passe
  </label>
</div>
<div class="col-lg-2" >
    <label for="inputPassword2" class="sr-only">Password</label>
    <input type="password" class="form-control" id="inputPassword2" name="Password" placeholder="Password">
</div>
</div>

&nbsp;&nbsp;&nbsp;&nbsp;
<div class="row">
  <div class="col-lg-2"></div>
<div class="col-lg-8">
<div>
  <input type="radio"  name="select" value="dateDebutFin">
  <label >Valable du <input type="date" name="dateDebut" value="dateDebut"> au <input type="date" name="dateFin1"> </label>
</div>

<div>
  <input type="radio" name="select" value="NbrClics">
  <label >Max <input type="number" name="clics"> Clics</label>
</div>

<div>
  <input type="radio"  name="select" value="dateFin">
  <label for="">Valable jusqu'au <input type="date" name="dateFin2"> </label>
</div>
</div>
</div>

    <div class="form-group row" id="Raccourcie">
      <div class="offset-sm-2 col-sm-10">
        <button type="submit" name="ctl" value="racourcirSelect" class="btn btn-primary" id="racourcii">Racourcir</button>
      </div>
    </div>
</form>


<?php if(isset($_POST['ctl']) and isset($_SESSION['UrlBzh'])){?>
<div class="row">
  <div class="col-lg-2"></div>
  <div class="col-lg-10">

    <p>Votre URL racourcie ->
<a href="www.<?php echo $_SESSION['UrlBzh'] ;?>"><?php echo $_SESSION['UrlBzh'] ;?></a></p>
  </div>

<?php }?>



        <?php include 'footer.php' ; ?>
  </body>
</html>
