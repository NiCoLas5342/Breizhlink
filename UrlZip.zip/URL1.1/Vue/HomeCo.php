<?php //session_start (); ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php include 'links.php' ;  ?>
    <title>URL</title>
  </head>
  <body>
    <header>
      <?php include 'HeaderCo.php' ; ?>
    </header>
    <p id="titre">
      Bonjour  <br>
 Vous pouvez désormais accéder à toutes nos options de création d’URL raccourcies <br>
Avec mot de passe<br>
A durée limitée<br>
A durée périodique<br>
Création par lots<br>
Visualisation des statistiques
      </p>
    <?php include 'footer.php' ; ?>
  </body>
</html>
