$(document).ready(function(){
	$("#inputPassword2").toggle(false);
	$("#LienUrl").toggle(false);
	$("#racourcii").click(function(){
		$("#LienUrl").slideToggle();

	});

	$("#check").change(function(){
	 if($("#check").is(":checked"))
	  {
		$("#inputPassword2").slideToggle();
	 }
	  else
	  {
		$("#inputPassword2").toggle(false);
	  }
     
	});






});


