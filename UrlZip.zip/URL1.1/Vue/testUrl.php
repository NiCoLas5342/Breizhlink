<p>
    racourcir URL
</p>

<form action="testUrl.php" method="post">
<p>
    <input type="url" name="URL" />
    <input type="submit" value="Valider" />
</p>
</form>
<?php 

if(isset($_POST['URL'])){
	$url = $_POST['URL'];
	echo $url."<br>" ;
}

echo rand(5, 15);

	?>