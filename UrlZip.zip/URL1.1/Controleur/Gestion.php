<?php
session_start ();
Require_once './Modele/Requete.php';
Require_once './Modele/Cryptage.php';

function genererChaineAleatoire($longueur = 5)
{
 $caracteres = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
 $longueurMax = strlen($caracteres);
 $chaineAleatoire = '';
 for ($i = 0; $i < $longueur; $i++)
 {
 $chaineAleatoire .= $caracteres[rand(0, $longueurMax - 1)];
 }
 return $chaineAleatoire;
}
$i =  genererChaineAleatoire(); 

if(isset($_POST['ctl']))
{ 
	$ctl = $_POST['ctl'];
	switch($ctl)
	{
		case 'Envoyer':
		{
              $addr = $_POST['url'];
              break ;

		}

		case'sup':{
			$id = $_REQUEST['id'];
			Requete::delete($id);
			include("./Vue/Home.php");
			break ; 

		}


		case'modif':{
		//	session_start ();
			$id = $_REQUEST['id'];
			$ligne = Requete::AfficherUneLigne($id);
			$_SESSION['ligne'] = $ligne; 
			include("./Vue/Modification.php");
			exit(); 

		}

		case'update':{
			$id = $_REQUEST['id'];
			$email = $_POST['email'];
			$nom = $_POST['login'];
			Requete::update($id,$email,$nom);
			include("./Vue/Home.php");
			break ; 
		}


		case 'deconnexion':
		{
			session_destroy();
			include("./Vue/Home.php");
            break ;

		}

	    case 'reduction':
		{
			
			$url = $_POST['url'];
			$_SESSION['url'] = $url; 
			
			$_SESSION['i'] = $i ; 
			$UrlBzh = "https://breizhlink.000webhostapp.com/URL1.1/links/$i.php" ; 


			if(isset($_POST['checkbox'])){
			$password = $_POST['Password'];
			$pass_hash = password_hash($password, PASSWORD_DEFAULT);

			$fichier= fopen("links/$i.php",'w+');
			$texte = "<?php \n";
			fwrite($fichier,$texte);

			$texte1 = " Require_once '../Modele/Requete.php'; \n";
			fwrite($fichier,$texte1);

			$texte2 = "include '../Vue/links.php' ; ?>\n";
			fwrite($fichier,$texte2);

			 $texte3 = "<form action='' method='post'>\n";
			fwrite($fichier,$texte3);

			$texte41 = '<p id="MdpLien">Ce lien est protégé par un mot de passe !<br>Entrez le mot de passe pour acceder au lien Breizhlink<br>';
			fwrite($fichier,$texte41);

			$texte41 = "\n";
			fwrite($fichier,$texte41);

			$texte42 = '<input type="password" name="password" />';
			fwrite($fichier,$texte42);

			

			$texte43 = '<input type="submit" value="Valider" />';
			fwrite($fichier,$texte43);

			$texte41 = "\n";
			fwrite($fichier,$texte41);

			$texte44 = '<br><img src="../Vue/logo.png"></p>';
			fwrite($fichier,$texte44);

			$texte41 = "\n";
			fwrite($fichier,$texte41);


			$texte45 = "</form>\n";
			fwrite($fichier,$texte45);

			$texte0 = "<?php \n";
			fwrite($fichier,$texte0);
			
			$texte0 = 'if(!empty($_POST["password"])){';
			fwrite($fichier,$texte0);
			
				$texte0 = "\n";
			fwrite($fichier,$texte0);

			$texte4 = '$url = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];';
			fwrite($fichier,$texte4);
			
            $texte41 = "\n";
			fwrite($fichier,$texte41);
			
			$texte41 = '$https = "https://";';
			fwrite($fichier,$texte41);
			
			$texte42 = "\n";
			fwrite($fichier,$texte42);

			$texte5 = '$mdp = $_POST["password"];';
			fwrite($fichier,$texte5);

			$texte41 = "\n";
			fwrite($fichier,$texte41);

			$texte6 = 'if($_POST["password"] != null){ ';
			fwrite($fichier,$texte6);

			$texte41 = "\n";
			fwrite($fichier,$texte41);

			$texte7 = '$donnee = Requete::addMdpHash($https.$url);';
			fwrite($fichier,$texte7);

			$texte41 = "\n";
			fwrite($fichier,$texte41);

			$texte8 = 'foreach($donnee as $uneLigne){$mdpHash = $uneLigne["mdp"];}';
			fwrite($fichier,$texte8);

			$texte42 = "\n";
			fwrite($fichier,$texte42);

			$texte9 = 'if (password_verify($mdp, $mdpHash)){ ';
			fwrite($fichier,$texte9);

			$texte42 = "\n";
			fwrite($fichier,$texte42);

			$texte20 = 'echo "';
			fwrite($fichier,$texte20);
			
			$texte42 = "<script type='text/javascript'>document.location.replace('";
			fwrite($fichier,$texte42);

			$texte01 = " $url" ;
			fwrite($fichier,$texte01);

			$texte3 = "');</script>";
			fwrite($fichier,$texte3);
			
			$texte3 ='";';
			fwrite($fichier,$texte3);

			$texte11 = " }\n";
			fwrite($fichier,$texte11);

			$texte12 = 'else {echo "<br>Mot de passe incorrect";';
			fwrite($fichier,$texte12);



			$texte11 = "\n";
			fwrite($fichier,$texte11);

			$texte14 = "} \n";
			fwrite($fichier,$texte14);

			$texte15 = " } \n";
			fwrite($fichier,$texte15);
			
			$texte15 = " } \n";
			fwrite($fichier,$texte15);

			$texte9 = "\n?> \n";
			fwrite($fichier,$texte9);
			fclose($fichier);
			Requete::addUrl($url,$pass_hash,$UrlBzh);
			} else{
            $fichier= fopen("links/$i.php",'w+');
			$texte = "<?php \n";
			fwrite($fichier,$texte);

			$texte = " \n";
			fwrite($fichier,$texte);
			$texte3 = 'header("Location:';
			fwrite($fichier,$texte3);
			$texte0 = " $url" ;
			fwrite($fichier,$texte0);
			$texte3 = '");';
			fwrite($fichier,$texte3);
			$texte2 = "\n?> \n";
			fwrite($fichier,$texte2);
			fclose($fichier);
			Requete::addUrl($url,'',$UrlBzh);
		}

			include("./Vue/Home.php");
             exit(); 

		}

		case 'tableau':{
			//session_start ();
			$liste = Requete::AfficherTableaux();
			$_SESSION['liste'] = $liste;  
			include("./Vue/tableaux.php");
            exit(); 
		}

		case 'search':{
		//	session_start ();
			$recherche = $_POST['rechercher'];
			$liste = Requete::SearchUneLigne($recherche);
			$_SESSION['liste'] = $liste;  
			include("./Vue/tableaux.php");
			exit(); 
		}
           
		case 'Connexion':{
		//	session_start ();
			$pseudo = $_POST['Pseudo'];
			$mdp = $_POST['Mdp'];
			$donnee = Requete::RecupMdp($pseudo);
			//echo "<br>test_>".$mdpHash ;
			//echo "<br>password hash ->".$mdpHash['password'];
			foreach($donnee as $uneLigne)
              {
              	$mdpHash = $uneLigne['password'];
              }
            
			if (password_verify($mdp, $mdpHash))
            {
            
             $_SESSION['login'] = $pseudo; 
             include("./Vue/HomeCo.php");
            break ;
            }
            else
            {
             echo "<br>Mot de passe incorrect";
             include("./Vue/Home.php");
             break ;
            
            }
			
           		}

		case 'CreationNewCompte':{
			$email = $_POST['email'];
			$nom = $_POST['login'];
			$password = $_POST['password'];
			$pass_hash = password_hash($password, PASSWORD_DEFAULT);
			$mail = 0 ; 

			

			$donnees = Requete::AllsMails();
            foreach($donnees as $uneLigne)
              {
                if ($uneLigne['mail'] == $email){
                	$mail = 1 ;
                	break ;
                }
                else{
                	$mail = 2 ; 

                }

            }
            
            if($mail == 0){
                // Il n'y a aucun profils
                $mail = 2 ;
            }

			if($mail == 2){
			   Requete::ajouter($email,$nom,$pass_hash); 
			    include("./Vue/Home.php");
		     }
		     else if($mail == 1){
		     $_SESSION['ErreurMail'] = "Cette adresse mail est déja utilsé"; 
		      
			
		     }
		      
     			break ;
		}

		case 'racourcirSelect':
		{
		//	session_start();
			$url = $_POST['url'];
			$_SESSION['url'] = $url; 
			
			$_SESSION['i'] = $i ; 
			$UrlBzh = "https://breizhlink.000webhostapp.com/URL1.1/links/$i.php" ;
			 $_SESSION['UrlBzh'] = $UrlBzh;

			$result = Requete::GenereIdProfils($_SESSION['login']);
            $idProfils = $result[0]['id'] ;
            
            if(!empty($_POST['select'])){
            $select = $_POST['select'];
            }

            $dateCreation = date("Y-m-d");

           

            if(!empty($_POST['Password'])){
            	$password = $_POST['Password'] ;
            	$pass_hash = password_hash($password, PASSWORD_DEFAULT);
            	
            	if(empty($_POST['select'])){
            	    Requete::addUrlMdp($idProfils,$url,$pass_hash,$UrlBzh,$dateCreation); 

            	}

            	else if($select == 'dateDebutFin'){
		              	$dateDebut = $_POST['dateDebut'];
		              	$dateFin = $_POST['dateFin1'];
		              	Requete::addUrlDateDebutFinMdp($idProfils,$url,$pass_hash,$UrlBzh,$dateDebut,$dateFin,$dateCreation );

		              }
		              else if($select == 'NbrClics'){
		              	$NombresClicsMax = $_POST['clics'];
		              	Requete::addUrlNbrClicsMaxMdp($idProfils,$url,$pass_hash,$UrlBzh,$NombresClicsMax,$dateCreation );

		              }
		              else if($select == 'dateFin'){
		              	$dateFin = $_POST['dateFin2'];
		              	Requete::addUrlDateFinMdp($idProfils,$url,$pass_hash,$UrlBzh,$dateFin,$dateCreation);
		              
		              }
		            
            	
            }
            else{ 


		             if($select == 'dateDebutFin'){
		              	$dateDebut = $_POST['dateDebut'];
		              	$dateFin = $_POST['dateFin1'];
		              	Requete::addUrlDateDebutFin($idProfils,$url,$UrlBzh,$dateDebut,$dateFin,$dateCreation );

		              }
		              else if($select == 'NbrClics'){
		              	$NombresClicsMax = $_POST['clics'];
		              	Requete::addUrlNbrClicsMax($idProfils,$url,$UrlBzh,$NombresClicsMax,$dateCreation );

		              }
		              else if($select == 'dateFin'){
		              	$dateFin = $_POST['dateFin2'];
		              	Requete::addUrlDateFin($idProfils,$url,$UrlBzh,$dateFin,$dateCreation);
		              
		              }
              }

            $fichier= fopen("links/$i.php",'w+');
			$texte = "<?php \n";
			fwrite($fichier,$texte);

			$texte1 = '$UrlBzh = $_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];';
			fwrite($fichier,$texte1);

			$texte1 = "\n";
			fwrite($fichier,$texte1);

			$texte1 = " session_start();\n";
			fwrite($fichier,$texte1);

			$texte1 = '$_SESSION["UrlBzh"]= $UrlBzh;';
			fwrite($fichier,$texte1);

			$texte1 = "\n";
			fwrite($fichier,$texte1);

			$texte1 = ' header("Location:https://breizhlink.000webhostapp.com/URL1.1/index.php?action=Reduction");';
			fwrite($fichier,$texte1);

			$texte1 = "\n";
			fwrite($fichier,$texte1);

			$texte1 = "?>\n";
			fwrite($fichier,$texte1);


              include("./Vue/RacourcirCo.php");
              break ;


		}
		
		
	}
}
else {
	include("./Vue/Home.php");
	exit();
              
}





?>


