<?php
session_start();
Require_once './Modele/Requete.php';
include './Vue/links.php';
$https = "https://";
$resultat = Requete::RecupUrlProfils($https.$_SESSION['UrlBzh']);
$Url      = $resultat[0]['Url'];
$UrlBzh   = $resultat[0]['UrlBzh'];
$today    = date("Y-m-d");
$droit    = 0;


if (isset($resultat[0]['mdp'])) {
?>
<form action='' method='post'>
<p id="MdpLien">Ce lien est protégé par un mot de passe !<br>Entrez le mot de passe pour acceder au lien Breizhlink<br>
<input type="password" name="password" /><input type="submit" value="Valider" />
<br><img src="./Vue/logo.png"></p>
</form>
<?php
   /* if(!empty($_POST["password"])){
    $mdp = $_POST["password"];
    }*/
    if (!empty($_POST["password"]) && $_POST["password"] != null) {
         $mdp = $_POST["password"];
        $donnee = Requete::addMdpHashProfils($UrlBzh);
        foreach ($donnee as $uneLigne) {
            $mdpHash = $uneLigne["mdp"];
        }
        if (password_verify($mdp, $mdpHash)) {
		  if (isset($resultat[0]['DateDebut'])) {
		        $DateDebut = $resultat[0]['DateDebut'];
		        $DateFin   = $resultat[0]['DateFin'];
		        if ($DateDebut < $today && $today < $DateFin) {
		            $droit = 1;
		        } else {
		            echo "Date plus valide";
		        }
		             
		    } else if (isset($resultat[0]['NombresClicsMax'])) {
		        $NbresClicsMax = $resultat[0]['NombresClicsMax'];
		        if ($resultat[0]['NombresClics'] < $resultat[0]['NombresClicsMax']) {
		            $droit = 1;
		        } else {
		            echo "Nombres de clics dépassé";
		        }
		        
		    } else if (isset($resultat[0]['DateFin'])) {
		        $DateFin = $resultat[0]['DateFin'];
		        if ($today < $DateFin) {
		            $droit = 1;
		        } else {
		            echo "Date plus valide";
		        }
		    }
		      else{
		             $droit = 1;
		        }
		    
		    
		    if ($droit == '1') {
		        $NombresClicsMaj = $resultat[0]['NombresClics'] + 1;
		        //echo $NombresClicsMaj ;
		        Requete::addClics($NombresClicsMaj, $https.$_SESSION['UrlBzh']);
        echo "<script type='text/javascript'>document.location.replace('$Url');</script>";
		        session_destroy();
		    }

        } else {
            echo "<br>Mot de passe incorrect vous n'avez pas acces a cette page";
        }
    }
    
} else {
    
    if (isset($resultat[0]['DateDebut'])) {
        $DateDebut = $resultat[0]['DateDebut'];
        $DateFin   = $resultat[0]['DateFin'];
        if ($DateDebut < $today && $today < $DateFin) {
            $droit = 1;
        } else {
            echo "Date plus valide";
        }
        
    } else if (isset($resultat[0]['NombresClicsMax'])) {
        $NbresClicsMax = $resultat[0]['NombresClicsMax'];
        if ($resultat[0]['NombresClics'] < $resultat[0]['NombresClicsMax']) {
            $droit = 1;
        } else {
            echo "Nombres de clics dépassé";
        }
        
    } else if (isset($resultat[0]['DateFin'])) {
        $DateFin = $resultat[0]['DateFin'];
        if ($today < $DateFin) {
            $droit = 1;
        } else {
            echo "Date plus valide";
        }
    }
    
    
    if ($droit == '1') {
        $NombresClicsMaj = $resultat[0]['NombresClics'] + 1;
       // echo $NombresClicsMaj ;
        Requete::addClics($NombresClicsMaj, $https.$_SESSION['UrlBzh']);
        echo "<script type='text/javascript'>document.location.replace('$Url');</script>";
        //header("Location:$Url");
        session_destroy();
    }
    
 }





?>