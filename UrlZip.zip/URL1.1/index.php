<?php

if(isset($_REQUEST['action']))
{ 
	$action = $_REQUEST['action'];
	switch($action)
	{
		case 'racourcir':
		{
			include("Controleur/Gestion.php");
			break ;
			
		}

		case 'Reduction':{
			include("Controleur/reduction.php");
			break ;

		}
		case 'creation':{
			include("./Vue/Creation.php");
			break ;
		}
		case 'SubmitCreationCompte':{
			include("Controleur/Gestion.php");
			break ;
		}
		case 'VerifIdentifiant':{
			include("Controleur/Gestion.php");
			break ;
		}
		case 'RacourcirCo':
		{
			session_start ();
			include('./Vue/RacourcirCo.php');
			break ;
		}
		case 'MonCompte':
		{
			session_start ();
			include('./Vue/recapCo.php');
			break ;
		}

		case 'HomeCo':
		{
			session_start ();
			include('./Vue/HomeCo.php');
			break ;

		}
	}
}
else {		
include("./Vue/Home.php");
}


?>